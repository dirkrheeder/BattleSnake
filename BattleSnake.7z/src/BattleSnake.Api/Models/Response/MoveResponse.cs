﻿namespace BattleSnake.Api.Models.Response;
public class MoveResponse
{
    public MoveDirection Move { get; set; }
    public string Shout { get; set; }
}
