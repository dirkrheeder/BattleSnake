﻿namespace BattleSnake.Core;

public enum MoveDirection
{
  Up,
  Down,
  Left,
  Right
}
