﻿namespace BattleSnake.Core.Models;

public class Customizations
{
  public string Color { get; set; }
  public string Head { get; set; }
  public string Tail { get; set; }
}
