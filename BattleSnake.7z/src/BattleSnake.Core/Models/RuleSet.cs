﻿namespace BattleSnake.Core.Models;

public class RuleSet
{
  public string Name { get; set; }
  public string Version { get; set; }
  public RuleSetSettings Settings { get; set; }
}
